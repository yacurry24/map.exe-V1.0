# Roblox-Visit-Bot
Simple roblox visit bot

# Notes:
* You will have to leave your PC afk while running this otherwise it will mess the bot up
* make sure that a cross bar is showing when your in a roblox game if not press F11 screenshot if your stuck on what i mean --> https://prnt.sc/13zl0w9

# Setup:
1) Make a alt on [Roblox](https://www.roblox.com/account/signupredir)
2) Next Download the latest version of this repo [Here](https://github.com/amprocode/Roblox-Visit-Bot/archive/refs/heads/main.zip)
3) Extract the files DONT RENAME ANY OF THE FILES!
4) Next go into main.py and go to line 18 and modify it and save
5) Finally go back onto your alt account and make sure it on the game page that you want botted, just like [this](https://prnt.sc/13zacl8)
6) Now you are done! Run the program and leave your PC afk!
